#!/bin/bash
cd ~/
cp ~/generator_gm/one_click_generator.sh ~/generator/
cp -r ~/generator/tmp_one_click ~/generator/tmp_one_click_gm
cd ~/generator/
bash ./one_click_generator.sh -g ./tmp_one_click_gm
