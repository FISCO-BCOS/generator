下载安装

解压generator_gm.zip包后执行如下：

1.执行

命令：./gm_init.sh

2.生成节点

命令：./gm_build
