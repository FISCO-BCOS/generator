#!/bin/bash

killall -9 fisco-bcos
cd ~/ && rm -rf generator
git clone https://github.com/FISCO-BCOS/generator.git
cd ~/generator && bash ./scripts/install.sh
./generator -h
./generator --download_fisco ./meta --cdn
./meta/fisco-bcos -v
